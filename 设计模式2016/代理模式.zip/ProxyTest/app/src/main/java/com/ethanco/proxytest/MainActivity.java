package com.ethanco.proxytest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ethanco.proxytest.dynamic_proxy_model.Client;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Client client = new Client();
        client.call();
    }
}

