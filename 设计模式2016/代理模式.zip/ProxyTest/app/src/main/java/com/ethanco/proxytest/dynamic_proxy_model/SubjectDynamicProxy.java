package com.ethanco.proxytest.dynamic_proxy_model;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

/**
 * Created by Zhk on 2016/1/1.
 */
public class SubjectDynamicProxy extends DynamicProxy {
    public static <T> T newProxyInstance(ISubject subject) {
        //获得ClassLoader
        ClassLoader classLoader = subject.getClass().getClassLoader();
        //获得接口数组
        Class<?>[] classes = subject.getClass().getInterfaces();
        InvocationHandler handler = new MyInvocationhandler(subject);

        //寻找JoinPoint连接点，AOP框架使用元数据定义
        if (true) {
            //执行一个前置通知
            (new BeforeAdvice()).exec();
        }

        return (T) Proxy.newProxyInstance(classLoader, classes, handler);
    }
}
