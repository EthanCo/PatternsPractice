package com.ethanco.proxytest.dynamic_proxy;

import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by Zhk on 2016/1/1.
 */
public class GamePlayIH implements InvocationHandler {

    //被代理者
    private Class cls = null;
    //被代理的实例
    private Object obj;

    public GamePlayIH(Object _obj) {
        this.obj = _obj;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        Object result = method.invoke(obj, args);
        if (method.getName().equalsIgnoreCase("login")) {
            Log.i("zhk-GamePlayIH", "invoke: 发送短信:有人在用你的账号登陆");
        }

        return result;
    }
}
