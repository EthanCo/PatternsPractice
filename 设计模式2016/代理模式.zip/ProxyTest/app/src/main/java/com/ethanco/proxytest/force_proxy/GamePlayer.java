package com.ethanco.proxytest.force_proxy;

import android.util.Log;

/**
 * Created by Zhk on 2016/1/1.
 */
public class GamePlayer implements IGamePlayer {

    private final String name;
    //我的代理
    private IGamePlayer proxy = null;

    public GamePlayer(String name) {
        this.name = name;
    }

    public IGamePlayer getProxy() {
        this.proxy = new GamePlayerProxy(this);
        return this.proxy;
    }

    @Override
    public void login(String user, String password) {
        if (isProxy()) {
            Log.i("zhk-GamePlayer", "login: " + "用户:" + this.name + " 用户名:" + user + "登陆成功" + "，登陆密码:" + password);
        } else {
            Log.i("zhk-GamePlayer", "upgrade: 请使用指定代理访问");
        }
    }

    @Override
    public void killBoss() {
        if (isProxy()) {
            Log.i("zhk-GamePlayer", "killBoss: " + name + "打boss");
        } else {
            Log.i("zhk-GamePlayer", "upgrade: 请使用指定代理访问");
        }
    }

    @Override
    public void upgrade() {
        if (isProxy()) {
            Log.i("zhk-GamePlayer", "upgrade: " + name + "升级");
        } else {
            Log.i("zhk-GamePlayer", "upgrade: 请使用指定代理访问");
        }
    }

    private boolean isProxy() {
        if (proxy == null) {
            return false;
        } else {
            return true;
        }
    }
}
