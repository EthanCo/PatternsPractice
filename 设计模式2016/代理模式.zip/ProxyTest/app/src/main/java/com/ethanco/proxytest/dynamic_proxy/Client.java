package com.ethanco.proxytest.dynamic_proxy;

import android.util.Log;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

/**
 * 动态代理
 * 面向切面编程 : AOP
 * <p/>
 * Created by Zhk on 2016/1/1.
 */
public class Client {
    public void call() {
        Log.i("zhk-Client", "call: 动态代理");

        IGamePlayer me = new GamePlayer("朱豪凯");
        InvocationHandler handler = new GamePlayIH(me);
        IGamePlayer gamePlayer = (IGamePlayer) Proxy.newProxyInstance(me.getClass().getClassLoader(), new Class[]{IGamePlayer.class}, handler);
        gamePlayer.login("z1406472408", "123456");
        gamePlayer.killBoss();
        gamePlayer.upgrade();
    }
}
