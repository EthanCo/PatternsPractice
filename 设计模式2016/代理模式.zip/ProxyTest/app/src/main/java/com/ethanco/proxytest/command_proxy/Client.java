package com.ethanco.proxytest.command_proxy;

import android.util.Log;

/**
 * 普通代理
 * 必须调用代理才能访问，不需要知道主题类的存在
 * <p/>
 * Created by Zhk on 2016/1/1.
 */
public class Client {
    public void call() {
        Log.i("zhk-Client", "call: 普通代理");
        IGamePlayer gamePlayer = new GamePlayerProxy("朱豪凯");
        gamePlayer.login("z1406472408", "123456");
        gamePlayer.killBoss();
        gamePlayer.upgrade();
    }
}
