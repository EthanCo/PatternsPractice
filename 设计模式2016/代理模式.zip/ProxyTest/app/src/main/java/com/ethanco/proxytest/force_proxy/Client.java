package com.ethanco.proxytest.force_proxy;

import android.util.Log;

/**
 * ## 强制代理 ##
 * 必须铜鼓真实角色查找到代理角色，否则不能访问
 * <p/>
 * 高层模块new了一个真实角色的对象，返回的却是代理角色。
 * Created by Zhk on 2016/1/1.
 */
public class Client {
    public void call() {
        Log.i("zhk-Client", "call: 强制代理");
        IGamePlayer me = new GamePlayer("朱豪凯");
        //代理给职业游戏者
        IGamePlayer gamePlayer = me.getProxy();
        gamePlayer.login("z1406472408", "123456");
        gamePlayer.killBoss();
        gamePlayer.upgrade();
    }
}
