package com.ethanco.proxytest.dynamic_proxy_model;

import android.util.Log;

/**
 * 动态代理
 * 面向切面编程 : AOP 模型
 * <p/>
 * Created by Zhk on 2016/1/1.
 */
public class Client {
    public void call() {
        Log.i("zhk-Client", "call: 动态代理模型");
        ISubject subject = new RealSubject();
//        MyInvocationhandler handler = new MyInvocationhandler(subject);
//        ISubject proxy = DynamicProxy.newProxyInstance(subject.getClass().getClassLoader(), new Class[]{ISubject.class}, handler);
        ISubject proxy = SubjectDynamicProxy.newProxyInstance(subject);
        proxy.doSomething("做一些事情....");
    }
}
