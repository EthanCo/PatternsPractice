package com.ethanco.proxytest.simple_proxy;

import android.util.Log;

/**
 * Created by Zhk on 2016/1/1.
 */
public class GamePlayer implements IGamePlayer {

    private final String name;

    public GamePlayer(String name) {
        this.name = name;
    }

    @Override
    public void login(String user, String password) {
        Log.i("zhk-GamePlayer", "login: " + "用户:" + this.name + " 用户名:" + user + "登陆成功" + "，登陆密码:" + password);
    }

    @Override
    public void killBoss() {
        Log.i("zhk-GamePlayer", "killBoss: " + name + "打boss");
    }

    @Override
    public void upgrade() {
        Log.i("zhk-GamePlayer", "upgrade: " + name + "升级");
    }
}
