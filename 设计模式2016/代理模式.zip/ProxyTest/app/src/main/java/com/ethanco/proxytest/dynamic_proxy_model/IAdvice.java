package com.ethanco.proxytest.dynamic_proxy_model;

/**
 * Created by Zhk on 2016/1/1.
 */
public interface IAdvice {
    void exec();
}
