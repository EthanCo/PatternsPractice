package com.ethanco.proxytest.simple_proxy;

/**
 * Created by Zhk on 2016/1/1.
 */
public class Client {
    public void call() {
        IGamePlayer me = new GamePlayer("朱豪凯");

        //代理给职业游戏者
        IGamePlayer gamePlayer = new GamePlayerProxy(me);
        gamePlayer.login("z1406472408", "123456");
        gamePlayer.killBoss();
        gamePlayer.upgrade();
    }
}
