package com.ethanco.proxytest.dynamic_proxy_model;

import android.util.Log;

/**
 * Created by Zhk on 2016/1/1.
 */
public class RealSubject implements ISubject {
    @Override
    public void doSomething(String str) {
        Log.i("zhk-RealSubject", "doSomething: .............." + str);
    }
}
