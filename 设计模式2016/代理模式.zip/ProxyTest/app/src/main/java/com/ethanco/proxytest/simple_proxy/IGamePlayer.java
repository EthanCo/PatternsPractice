package com.ethanco.proxytest.simple_proxy;

/**
 * Created by Zhk on 2016/1/1.
 */
public interface IGamePlayer {
    void login(String user,String password);
    void killBoss();
    void upgrade();
}
