package com.ethanco.proxytest.dynamic_proxy_model;

import android.util.Log;

/**
 * Created by Zhk on 2016/1/1.
 */
public class BeforeAdvice implements IAdvice {
    @Override
    public void exec() {
        Log.i("zhk-BeforeAdvice", "exec: 前置通知被执行了");
    }
}
