package com.ethanco.proxytest.dynamic_proxy_model;

/**
 * 抽象主题
 * <p/>
 * Created by Zhk on 2016/1/1.
 */
public interface ISubject {
    /**
     * 业务操作
     */
    public void doSomething(String str);
}
