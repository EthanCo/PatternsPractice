package com.ethanco.proxytest.dynamic_proxy_model;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * Created by Zhk on 2016/1/1.
 */
public class MyInvocationhandler implements InvocationHandler {
    //被代理对象
    private Object obj = null;

    public MyInvocationhandler(Object _obj) {
        this.obj = _obj;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        return method.invoke(obj, args);
    }
}
