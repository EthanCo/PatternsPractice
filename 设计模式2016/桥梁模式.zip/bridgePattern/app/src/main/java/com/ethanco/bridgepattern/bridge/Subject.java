package com.ethanco.bridgepattern.bridge;

/**
 * 学科
 * <p/>
 * Created by EthanCo on 2016/1/8.
 */
public abstract class Subject {
    public abstract void showKnowledge();
}
