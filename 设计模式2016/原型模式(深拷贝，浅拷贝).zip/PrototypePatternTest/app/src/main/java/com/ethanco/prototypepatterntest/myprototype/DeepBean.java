package com.ethanco.prototypepatterntest.myprototype;

import java.util.ArrayList;

/**
 * 深拷贝
 * <p/>
 * Created by Zhk on 2016/1/2.
 */
public class DeepBean implements Cloneable {

    public DeepBean(String name, int age, ArrayList<String> info) {
        this.name = name;
        this.age = age;
        this.info = info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public ArrayList<String> getInfo() {
        return info;
    }

    public void setInfo(ArrayList<String> info) {
        this.info = info;
    }

    String name;
    int age;
    ArrayList<String> info = new ArrayList<>();

    @Override
    public DeepBean clone() throws CloneNotSupportedException {
        DeepBean bean = (DeepBean) super.clone();
        bean.setInfo((ArrayList<String>) this.info.clone());
        return bean;
    }

    @Override
    public String toString() {
        return "DeepBean{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", info=" + info +
                '}';
    }
}
