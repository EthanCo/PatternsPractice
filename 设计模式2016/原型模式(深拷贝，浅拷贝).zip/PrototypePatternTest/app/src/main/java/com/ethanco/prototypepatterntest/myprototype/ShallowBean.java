package com.ethanco.prototypepatterntest.myprototype;

import java.util.ArrayList;
import java.util.List;

/**
 * 浅拷贝
 * <p/>
 * Created by Zhk on 2016/1/2.
 */
public class ShallowBean implements Cloneable {
    public ShallowBean(String name, int age, List<String> info) {
        this.name = name;
        this.age = age;
        this.info = info;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public List<String> getInfo() {
        return info;
    }

    public void setInfo(List<String> info) {
        this.info = info;
    }

    String name;
    int age;
    List<String> info = new ArrayList<>();

    @Override
    public ShallowBean clone() throws CloneNotSupportedException {
        //浅拷贝
        return (ShallowBean) super.clone();
    }

    @Override
    public String toString() {
        return "Bean{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", info=" + info +
                '}';
    }
}
