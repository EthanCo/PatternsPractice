package com.ethanco.prototypepatterntest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.ethanco.prototypepatterntest.myprototype.DeepBean;
import com.ethanco.prototypepatterntest.myprototype.ShallowBean;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //浅拷贝
        shallowCopy();

        //深拷贝
        DeepCopy();
    }

    private void DeepCopy() {
        ArrayList<String> list = new ArrayList<>();
        list.add("升高170");
        list.add("体重100斤");
        DeepBean origin = new DeepBean("zhk", 18, list);
        Log.i("zhk-MainActivity", "onCreate: origin:" + origin.toString());
        try {
            DeepBean newBean = origin.clone();
            newBean.getInfo().add("智商180");
            Log.i("zhk-MainActivity", "onCreate: origin:" + origin.toString());
            Log.i("zhk-MainActivity", "onCreate: newBean:" + newBean.toString());
        } catch (CloneNotSupportedException e) {
            Log.e("zhk-MainActivity", "onCreate: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void shallowCopy() {
        List<String> list = new ArrayList<>();
        list.add("升高170");
        list.add("体重100斤");
        ShallowBean origin = new ShallowBean("zhk", 18, list);
        Log.i("zhk-MainActivity", "onCreate: origin:" + origin.toString());
        try {
            ShallowBean newBean = origin.clone();
            newBean.getInfo().add("智商180");
            Log.i("zhk-MainActivity", "onCreate: origin:" + origin.toString());
            Log.i("zhk-MainActivity", "onCreate: newBean:" + newBean.toString());
        } catch (CloneNotSupportedException e) {
            Log.e("zhk-MainActivity", "onCreate: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
