package com.ethanco.buildertest.buildpattern;

import android.util.Log;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BmwCar extends Car {
    @Override
    public void alarm() {
        Log.i("zhk-BMWModel", "alarm: 宝马车鸣喇叭");
    }

    @Override
    public void drive() {
        Log.i("zhk-BMWModel", "drive: 驾驶宝马车");
    }

    @Override
    public void playMusic() {
        Log.i("zhk-BMWModel", "playMusic: 在宝马车中播放音乐");
    }
}
