package com.ethanco.buildertest.buildpattern;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zhk on 2015/12/30.
 */
public abstract class Car {
    public void setSequenceList(List<String> sequenceList) {
        this.sequenceList = sequenceList;
    }

    protected List<String> sequenceList = new ArrayList<String>();

    public abstract void alarm();

    public abstract void drive();

    public abstract void playMusic();

    public void run() {
        for (int i = 0; i < sequenceList.size(); i++) {
            String tag = sequenceList.get(i);
            if (tag.equals("alarm")) {
                alarm();
            } else if (tag.equals("drive")) {
                drive();
            } else if (tag.equals("playMusic")) {
                playMusic();
            }
        }
    }
}
