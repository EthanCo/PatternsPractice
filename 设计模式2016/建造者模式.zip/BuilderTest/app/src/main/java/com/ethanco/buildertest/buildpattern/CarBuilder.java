package com.ethanco.buildertest.buildpattern;

import java.util.List;

/**
 * Created by Zhk on 2015/12/30.
 */
public abstract class CarBuilder {
    public abstract void setSequence(List<String> sequenceList);

    public abstract Car getCar();
}
