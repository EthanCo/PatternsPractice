package com.ethanco.buildertest.buildpattern;

import android.util.Log;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BenzCar extends Car {
    @Override
    public void alarm() {
        Log.i("zhk-BenzCar", "alarm: 奔驰鸣喇叭");
    }

    @Override
    public void drive() {
        Log.i("zhk-BenzCar", "drive: 驾驶奔驰车");
    }

    @Override
    public void playMusic() {
        Log.i("zhk-BenzCar", "playMusic: 在奔驰中播放音乐");
    }
}
