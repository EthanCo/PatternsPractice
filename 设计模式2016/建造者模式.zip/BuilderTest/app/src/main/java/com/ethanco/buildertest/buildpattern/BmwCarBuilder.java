package com.ethanco.buildertest.buildpattern;

import java.util.List;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BmwCarBuilder extends CarBuilder {
    Car car = new BmwCar();

    @Override
    public void setSequence(List<String> sequenceList) {
        car.setSequenceList(sequenceList);
    }

    @Override
    public Car getCar() {
        return car;
    }
}
