package com.ethanco.buildertest.buildpattern;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Zhk on 2015/12/30.
 */
public class Director {
    private List<String> sequence = new ArrayList();
    private BmwCarBuilder bmwCarBuilder = new BmwCarBuilder();
    private BenzCarBuilder benzCarBuilder = new BenzCarBuilder();

    public Car getABenzCar() {
        sequence.clear();
        sequence.add("alarm");
        sequence.add("drive");
        sequence.add("playMusic");
        benzCarBuilder.setSequence(sequence);
        return benzCarBuilder.getCar();
    }

    public Car getBBenzCar() {
        sequence.clear();
        sequence.add("drive");
        sequence.add("playMusic");
        sequence.add("alarm");
        benzCarBuilder.setSequence(sequence);
        return benzCarBuilder.getCar();
    }

    public Car getABmwCar(){
        sequence.clear();
        sequence.add("alarm");
        sequence.add("drive");
        sequence.add("playMusic");
        bmwCarBuilder.setSequence(sequence);
        return bmwCarBuilder.getCar();
    }


    public Car getBBmwCar(){
        sequence.clear();
        sequence.add("drive");
        sequence.add("playMusic");
        sequence.add("alarm");
        bmwCarBuilder.setSequence(sequence);
        return bmwCarBuilder.getCar();
    }
}
