package com.ethanco.buildertest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.ethanco.buildertest.buildpattern.Car;
import com.ethanco.buildertest.buildpattern.Director;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < 3; i++) {
            Director director = new Director();
            Car car = director.getABenzCar();
            car.run();
        }

        Log.i("zhk-MainActivity", "onCreate: =================================");

        for (int i = 0; i < 3; i++) {
            Director director = new Director();
            Car car = director.getBBenzCar();
            car.run();
        }

        Log.i("zhk-MainActivity", "onCreate: =================================");

        for (int i = 0; i < 3; i++) {
            Director director = new Director();
            Car car = director.getABmwCar();
            car.run();
        }

        Log.i("zhk-MainActivity", "onCreate: =================================");

        for (int i = 0; i < 3; i++) {
            Director director = new Director();
            Car car = director.getBBmwCar();
            car.run();
        }

    }
}
