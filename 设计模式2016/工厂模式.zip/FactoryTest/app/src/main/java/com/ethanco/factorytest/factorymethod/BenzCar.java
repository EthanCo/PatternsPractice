package com.ethanco.factorytest.factorymethod;

import android.util.Log;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BenzCar implements ICar {
    @Override
    public void drive() {
        Log.i("zhk-BenzCar", "drive: 驾驶奔驰车");
    }
}
