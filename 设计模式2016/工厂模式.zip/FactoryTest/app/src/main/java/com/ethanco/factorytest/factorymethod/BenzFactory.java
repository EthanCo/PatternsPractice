package com.ethanco.factorytest.factorymethod;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BenzFactory extends CarFactory {
    @Override
    public ICar createCar() {
        return new BenzCar();
    }
}
