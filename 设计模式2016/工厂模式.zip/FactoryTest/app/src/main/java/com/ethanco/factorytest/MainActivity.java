package com.ethanco.factorytest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ethanco.factorytest.factorymethod.BmwFactory;
import com.ethanco.factorytest.factorymethod.CarFactory;
import com.ethanco.factorytest.factorymethod.ICar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //CarFactory factory = new BenzFactory();
        CarFactory factory = new BmwFactory();
        ICar car = factory.createCar();
        car.drive();
    }
}
