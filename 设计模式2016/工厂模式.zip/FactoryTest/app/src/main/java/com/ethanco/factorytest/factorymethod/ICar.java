package com.ethanco.factorytest.factorymethod;

/**
 * Created by Zhk on 2015/12/30.
 */
public interface ICar {
    void drive();
}
