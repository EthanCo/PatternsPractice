package com.ethanco.abstractfactorytest.abstractfactory;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BenzFactory extends CarFactory {
    @Override
    public ICar createCar() {
        return new BenzCar();
    }

    @Override
    public ICushion createCushion() {
        return new BlueCushion();
    }
}
