package com.ethanco.abstractfactorytest.abstractfactory;

import android.util.Log;

/**
 * Created by Zhk on 2015/12/30.
 */
public class RedCushion implements ICushion {
    @Override
    public void showColor() {
        Log.i("zhk-RedCushion", "showColor: 红色的垫子");
    }
}
