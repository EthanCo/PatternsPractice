package com.ethanco.abstractfactorytest.abstractfactory;

import android.util.Log;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BmwCar implements ICar {
    @Override
    public void drive() {
        Log.i("zhk-BmwCar", "drive: 驾驶宝马车");
    }
}
