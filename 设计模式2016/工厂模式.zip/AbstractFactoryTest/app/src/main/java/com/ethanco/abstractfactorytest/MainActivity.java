package com.ethanco.abstractfactorytest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.ethanco.abstractfactorytest.abstractfactory.BenzFactory;
import com.ethanco.abstractfactorytest.abstractfactory.CarFactory;
import com.ethanco.abstractfactorytest.abstractfactory.ICar;
import com.ethanco.abstractfactorytest.abstractfactory.ICushion;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CarFactory factory = new BenzFactory();
        //CarFactory factory = new BmwFactory();
        ICar car = factory.createCar();
        ICushion iCushion = factory.createCushion();
        iCushion.showColor();
        car.drive();
    }
}
