package com.ethanco.abstractfactorytest.abstractfactory;

import android.util.Log;

/**
 * Created by Zhk on 2015/12/30.
 */
public class BlueCushion implements ICushion {
    @Override
    public void showColor() {
        Log.i("zhk-BlueCushion", "showColor: 蓝色的垫子");
    }
}
