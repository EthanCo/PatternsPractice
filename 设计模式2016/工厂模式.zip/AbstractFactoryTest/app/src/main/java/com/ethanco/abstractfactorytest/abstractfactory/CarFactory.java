package com.ethanco.abstractfactorytest.abstractfactory;

/**
 * Created by Zhk on 2015/12/30.
 */
public abstract class CarFactory {
    public abstract ICar createCar();

    public abstract ICushion createCushion();
}
