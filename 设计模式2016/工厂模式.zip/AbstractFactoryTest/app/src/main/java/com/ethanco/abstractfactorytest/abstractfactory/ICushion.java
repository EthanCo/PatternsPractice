package com.ethanco.abstractfactorytest.abstractfactory;

/**
 * Created by Zhk on 2015/12/30.
 */
public interface ICushion {
    void showColor();
}
